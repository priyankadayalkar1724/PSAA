---------Readme------------
#######Intructions#########
Download the zip file.
Once downloaded extract the zip file to the location of your choice.
After Opening the file Navigate to Paper Auto Arranger.
In paper Auto Arranger opne index.html